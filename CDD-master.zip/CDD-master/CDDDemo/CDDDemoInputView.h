//
//  CDDDemoInputView.h
//  CDDDemo
//
//  Created by gao feng on 16/2/4.
//  Copyright © 2016年 gao feng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDDDemoInputView : UIView

- (void)initInputView;

@end
