//
//  CDDUserDetailController.h
//  CDDDemo
//
//  Created by gao feng on 16/2/16.
//  Copyright © 2016年 gao feng. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UserProfile;

@interface CDDUserDetailController : UIViewController

@property (nonatomic, strong) UserProfile*                 user;

@end
